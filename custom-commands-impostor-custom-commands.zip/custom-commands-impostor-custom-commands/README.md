# custom-commands
This bot is licensed under https://license.darkdevs.net

No support will be provided by the owner
